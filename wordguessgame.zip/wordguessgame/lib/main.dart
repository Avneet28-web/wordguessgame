import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Disable the debug banner
      title: 'Word Guess Game',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HangmanGame()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.pinkAccent, Colors.orangeAccent, Colors.blueAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/logo.jpg', // Replace with your logo file
                width: 200,
                height: 200,
              ),
              const SizedBox(height: 20),
              const Text(
                'Welcome to Word Guess Game!',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HangmanGame extends StatefulWidget {
  const HangmanGame({super.key});

  @override
  State<HangmanGame> createState() => _HangmanGameState();
}

class _HangmanGameState extends State<HangmanGame> {
  static const List<String> words = [
    'bottle',
    'magic',
    'unicorn',
    'fragrance',
    'umbrella',
    'skirt',
    'chocolates',
    'piano',
    'icecream',
    'rainbow',
  ];

  static const Map<String, String> wordImages = {
    'bottle': 'assets/bottle.jpg',
    'magic': 'assets/magic.jpg',
    'unicorn': 'assets/unicorn.jpg',
    'fragrance': 'assets/fragrance.jpg',
    'umbrella': 'assets/umbrella.jpg',
    'skirt': 'assets/skirt.jpg',
    'chocolates': 'assets/chocolates.jpg',
    'piano': 'assets/piano.jpg',
    'icecream': 'assets/icecream.jpg',
    'rainbow': 'assets/rainbow.jpg',
  };

  late String currentWord;
  late List<String> guessedLetters;
  late int wrongGuesses;
  static const int maxWrongGuesses = 6;
  int wordIndex = 0;

  @override
  void initState() {
    super.initState();
    _startNewGame();
  }

  void _startNewGame() {
    setState(() {
      currentWord = words[wordIndex % words.length];
      guessedLetters = [];
      wrongGuesses = 0;
      wordIndex++;
    });
  }

  void _guessLetter(String letter) {
    setState(() {
      if (!guessedLetters.contains(letter)) {
        guessedLetters.add(letter);
        if (!currentWord.contains(letter)) {
          wrongGuesses++;
        }
      }
    });
  }

  String _getDisplayedWord() {
    return currentWord.split('').map((letter) {
      return guessedLetters.contains(letter) ? letter : '_';
    }).join(' ');
  }

  bool get _hasWon => _getDisplayedWord().replaceAll(' ', '') == currentWord;
  bool get _hasLost => wrongGuesses >= maxWrongGuesses;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Word Guess Game'),
        backgroundColor: Colors.deepPurple,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.purpleAccent, Colors.yellowAccent, const Color.fromARGB(255, 105, 220, 240)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: _hasWon || _hasLost
              ? Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      _hasWon ? 'You WON!' : 'You LOST!',
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'The word was: $currentWord',
                      style: const TextStyle(fontSize: 24, color: Colors.white),
                    ),
                    const SizedBox(height: 20),
                    Image.asset(
                      wordImages[currentWord] ?? 'assets/bottle.jpg', // Use a default image
                      width: 200,
                      height: 200,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Text(
                          'Image not found',
                          style: TextStyle(fontSize: 16, color: Colors.red),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _startNewGame,
                      child: const Text('Play Again'),
                    ),
                  ],
                )
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      wordImages[currentWord] ?? 'assets/bottle.jpg', // Display hint image
                      width: 200,
                      height: 200,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Text(
                          'Image not found',
                          style: TextStyle(fontSize: 16, color: Colors.red),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Wrong Guesses: $wrongGuesses / $maxWrongGuesses',
                      style: const TextStyle(fontSize: 20, color: Colors.white),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      _getDisplayedWord(),
                      style: const TextStyle(fontSize: 32, letterSpacing: 2, color: Colors.white),
                    ),
                    const SizedBox(height: 20),
                    Wrap(
                      spacing: 10,
                      children: 'abcdefghijklmnopqrstuvwxyz'.split('').map((letter) {
                        return ElevatedButton(
                          onPressed: guessedLetters.contains(letter) || _hasLost || _hasWon
                              ? null
                              : () => _guessLetter(letter),
                          child: Text(letter.toUpperCase()),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Guessed Letters: ${guessedLetters.join(', ')}',
                      style: const TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
